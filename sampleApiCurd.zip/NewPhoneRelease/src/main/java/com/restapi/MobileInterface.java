package com.restapi;

import org.springframework.data.jpa.repository.JpaRepository;

public interface MobileInterface extends JpaRepository<MobilePojo,Integer> {

}
