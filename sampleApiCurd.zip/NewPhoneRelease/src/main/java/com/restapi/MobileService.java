package com.restapi;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class MobileService {

	@Autowired
	private MobileInterface repo;
	
	
	public List<MobilePojo> listAll(){
		
		return repo.findAll();
	}
	
	
	public void save(MobilePojo product) {
		repo.save(product);
	}
	
	public MobilePojo get(int id) {
		return repo.findById(id).get();
		
	}
	
	public void delete(int id) {
		
		repo.deleteById(id);
	}
	

	
	
}
