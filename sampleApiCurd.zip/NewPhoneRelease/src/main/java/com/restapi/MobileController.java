package com.restapi;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class MobileController {
	@Autowired 
	MobileService service;
	
	@GetMapping("/home")
	public String viewHomePage() {
		return "Welcome to My Application";
	}
	@GetMapping("/retrive")
public List<MobilePojo> retriveProduts(){
		
		return service.listAll();
	}

	@PostMapping("/new")
	public String showNewProductForm() {
		MobilePojo product = new MobilePojo();
		product.setId(8);
		product.setModel("I Phone 12");
		product.setPrice(1200.0);
		product.setYear("2020");
		service.save(product);
		System.out.println(product.getModel());
		product.setId(10);
		product.setModel("I Phone 11");
		product.setPrice(1100.55);
		product.setYear("2019");
		service.save(product);
		product.setId(11);
		product.setModel("I Phone 10");
		product.setPrice(1000.0);
		product.setYear("2017");
		service.save(product);
 		return "new entrys added and saved";
	}

	@PatchMapping("/edit/{id}")
	public String showEditProductForm(@PathVariable(name="id") int id) {

		MobilePojo product = service.get(id);
		product.setModel("xxx");
		service.save(product);
		return "Updated the record";
	}
	@DeleteMapping("/delete/{id}")
	//@RequestMapping("/delete")
	public String deleteProduct(@PathVariable(name="id") int id) {
		MobilePojo product=new MobilePojo();
		service.delete(id);
		service.save(product);
		return "entry deleted";
	}
	
}
