package com.restapi;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="mobile_pojo")
public class MobilePojo {
	
	@Id
	@Column
	//@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;
	@Column
	private String model;
	@Column
	private Double price;
	@Column
	private String year;
	
	//Constructors
	public MobilePojo() {
	}

	//Getters and Setters
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getModel() {
		return model;
	}
	public void setModel(String model) {
		this.model = model;
	}
	public Double getPrice() {
		return price;
	}
	public void setPrice(Double price) {
		this.price = price;
	}
	public String getYear() {
		return year;
	}
	public void setYear(String year) {
		this.year = year;
	}
	

	

}
